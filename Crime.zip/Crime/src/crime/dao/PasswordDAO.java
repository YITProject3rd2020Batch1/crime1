package crime.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import crime.model.*;
	
	public class PasswordDAO{
		private static Connection con; 
		private static PreparedStatement stmt;
		public static void getConnection()
		  {
			  try {
			  Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
			  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/crimeDB","root",""); 
			  }
			  catch(SQLException e)
			  {	  e.printStackTrace();	  }
			  catch(Exception e)
			  {	  e.printStackTrace();	  }  	  
			  
		  }
		
		public static void closeConnection()
		  {
			  try{
				  if(con.isClosed()==false)
			          con.close();   // closing the connection
			  }
			  catch(Exception e)
			  { e.printStackTrace();	 }
		  }


		  public static boolean forgot(Registermodel forg)
		  {
			  boolean status=false;
			  try{
				  getConnection();
				  stmt=con.prepareStatement("select * from registration where email=? and sec_qn=? sec_ans=?");
				  stmt.setString(1,forg.getEmail());
				  stmt.setString(2, forg.getSec_qn());
				  stmt.setString(3, forg.getSec_ans());
				   ResultSet rs=stmt.executeQuery();  
				  status=rs.next(); 
				  closeConnection();
				   return true;
				    }
				  catch(SQLException e)
				  {
				  e.printStackTrace();
				  return false;
				  }
				  catch(Exception e)
				  {
				  e.printStackTrace();
				  return false;
				  }  	  	  
				  
			  }	 
	}

		
		
		
		
		
		
		
		
		
		
		
		
